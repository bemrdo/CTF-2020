Hai hai Kazuma desu.

Last year, I was reincarnated into the fantasy world after being hit by Truck-kun. Moreover, I was entrapped with a useless goddess, a chuunibyou and weird companion. Overall, this is a diary of my own journey 